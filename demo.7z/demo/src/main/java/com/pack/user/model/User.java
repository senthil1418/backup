package com.pack.user.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_user")
public class User {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
private Integer id;
private String email;
@Column(name="first_name")
private String firstname;
@Column(name="last_name")
private String lastname;
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getFirstname() {
	return firstname;
}
public void setFirstname(String firstname) {
	this.firstname = firstname;
}
public String getLastname() {
	return lastname;
}
public void setLastname(String lastname) {
	this.lastname = lastname;
}
public User(Integer id, String email, String firstname, String lastname) {
	super();
	this.id = id;
	this.email = email;
	this.firstname = firstname;
	this.lastname = lastname;
}
public User() {
	super();
	// TODO Auto-generated constructor stub
}

}
