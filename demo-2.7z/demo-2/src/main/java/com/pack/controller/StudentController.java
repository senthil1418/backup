package com.pack.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pack.model.Student;
import com.pack.repoistory.StudentRepoistory;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api")
public class StudentController {
     @Autowired
	 StudentRepoistory repoistory;
     
     @CrossOrigin(origins="http://localhost:4200")
     @GetMapping("/students/fetch")
     public List<Student> getAllStudents() {
       System.out.println("Get all Student...");
    
       List<Student> students = new ArrayList<>();
       repoistory.findAll().forEach(students::add);
    
       return students;
     }
     
     @PostMapping(value = "/students/create")
     public Student postCustomer(@RequestBody Student student) {
    
    	 Student _student = repoistory.save(new Student(student.getFirstname(), student.getLastname(),student.getEmail()));
       return _student;
     }
     
     @DeleteMapping("/students/{id}")
     public ResponseEntity<String> deleteStudent(@PathVariable("id") Integer id) {
       System.out.println("Delete Customer with ID = " + id + "...");
    
       repoistory.deleteById(id);
    
       return new ResponseEntity<>("Customer has been deleted!", HttpStatus.OK);
     }
     
     @DeleteMapping("/students/delete")
     public ResponseEntity<String> deleteAllStudents() {
       System.out.println("Delete All Students...");
    
       repoistory.deleteAll();
    
       return new ResponseEntity<>("All customers have been deleted!", HttpStatus.OK);
     }
     
     @PutMapping(value = "/students/update")
     public Student updateStudent(@RequestBody Student student) {
    
    	 Student _student = repoistory.save(new Student(student.getId(),student.getFirstname(), student.getLastname(),student.getEmail()));
       return _student;
     }
}
