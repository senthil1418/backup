export class Book{
    id: string;
    title: string;
    author: string;
    constructor(){
        
    }
}